package witchel.cs371m.fcintent;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class ScoreBoard extends AppCompatActivity {

    protected ArrayList<Score> highScores;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_score_board);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        this.highScores = new ArrayList<>();
        this.addHighScore(new Score("A Student", 999));
        this.addHighScore(new Score("Frank Zappa", 997));
        this.addHighScore(new Score("Barack Obama", 123));
        this.addHighScore(new Score("Haters who hate", 13));

        this.renderHighScores();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_score_board, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        } else if (id == R.id.menu_exit) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    protected void addHighScore(Score score) {
        boolean inserted = false;
        for (int iii = 0; iii < this.highScores.size(); iii++) {
            if (score.getScore() > this.highScores.get(iii).getScore()) {
                this.highScores.add(iii, score);
                inserted = true;
                break;
            }
        }
        if (!inserted) {
            this.highScores.add(score);
        }
        renderHighScores();
    }

    protected void renderHighScores() {
        String[] renderThese = new String[this.highScores.size()];
        for (int iii = 0; iii < this.highScores.size(); iii++) {
            renderThese[iii] = this.highScores.get(iii).toString();
        }
        ListAdapter theAdaptor = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, renderThese);
        ListView highScores = (ListView) findViewById(R.id.highScoreList);
        highScores.setAdapter(theAdaptor);
    }

    public void playButtonIsPressed(View view) {
        EditText userNameEditText = (EditText) findViewById(R.id.nameField);
        if (userNameEditText.getText().toString().isEmpty()) {
            // XXX write a Toast to warn the user about empty names.
        } else {
            // XXX Launch TheGame activity
        }
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
       // XXX write this entire function
    }
}
