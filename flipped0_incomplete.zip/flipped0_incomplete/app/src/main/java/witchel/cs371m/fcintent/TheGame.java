package witchel.cs371m.fcintent;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

/**
 * Created by cody on 9/8/15, modified by witchel
 */
public class TheGame extends AppCompatActivity {

    protected String currentUser;

    protected int theAnswer;
    protected int guesses;
    protected Toast mainToast;

    protected void doToast(String message) {
        if (this.mainToast != null) {
            this.mainToast.cancel();
        }
        this.mainToast = Toast.makeText(this, message, Toast.LENGTH_LONG);
        this.mainToast.show();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //XXX write the start of this function

        // XXX you can stop here
        this.guesses = 0;
        this.theAnswer = (new Random()).nextInt(101);

        if (this.currentUser.equals("Cody") || this.currentUser.equals("cody")) {
            this.doToast("Master, the number is " + Integer.toString(this.theAnswer));
            TextView maxScorePossible = (TextView) findViewById(R.id.maxScoreText);
            maxScorePossible.setText("Max score possible: 10000");
        }
    }

    public void guessButton(View view) {
        EditText theGuess = (EditText) findViewById(R.id.theGuess);
        if (theGuess.getText().toString().equals("")) {
            return;
        }

        int guessInt = Integer.parseInt(theGuess.getText().toString());

        guesses += 1;

        TextView guessText = (TextView) findViewById(R.id.currentGuessText);
        guessText.setText("Guesses: " + this.guesses);

        TextView maxScorePossible = (TextView) findViewById(R.id.maxScoreText);
        maxScorePossible.setText("Max score possible: " + this.computePossibleScore());

        if (guessInt < this.theAnswer) {
            this.doToast("Too low");
        } else if (guessInt > this.theAnswer) {
            this.doToast("Too high");
        } else {
            this.doToast("Correct");
            // Delay 2s to allow message
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    TheGame.this.correct();
                }
            }, 2000);
        }
        theGuess.setText("");
    }

    protected int computePossibleScore() {
        int result = 1000 - (int) Math.pow(2, this.guesses - 1);
        if (this.currentUser.equals("Cody") || this.currentUser.equals("cody")) {
            result *= 10;
        }
        return result;
    }

    protected int computeScore() {
        int result = 1000 - (int) Math.pow(2, this.guesses - 2);
        if (this.currentUser.equals("Cody") || this.currentUser.equals("cody")) {
            result *= 10;
        }
        return result;
    }

    protected void correct() {
        // XXX Write this entire function
    }
}
